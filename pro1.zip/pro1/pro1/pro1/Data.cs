﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro1
{
    public class Data
    {
        public string num {  get; set; }
        public string word { get; set; }
        public string mean { get; set; }
    }
}
